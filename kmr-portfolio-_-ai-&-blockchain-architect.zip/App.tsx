import React from 'react';
import Layout from './components/Layout';
import Hero from './components/Hero';
import Projects from './components/Projects';
import Roadmap from './components/Roadmap';
import TechStack from './components/TechStack';
import Contact from './components/Contact';

const App: React.FC = () => {
  return (
    <Layout>
      <Hero />
      <Projects />
      <Roadmap />
      <TechStack />
      <Contact />
    </Layout>
  );
};

export default App;